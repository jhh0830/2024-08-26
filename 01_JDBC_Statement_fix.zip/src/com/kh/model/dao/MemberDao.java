package com.kh.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.kh.model.vo.Member;
/*
 * Dao (Data Access Object)
 * Controller 를 통해서 호출된 기능을 수행하기 위해
 * 데이터가 담겨있는 외부매체인 DB 에 직접적으로 접근한 후
 * 해당 SQL 문을 실행하고 결과를 받아주는 부분
 * > 즉, JDBC 과정을 처리하는 부분
 * 
 */

/*
 * * JDBC 용 객체
 * - Connection : DB 의 연결정보를 담고 있는 객체
 * 				  Connection 객체가 생성되는 순간
 * 				  해당 DB 와의 연결이 이루어짐
 * - (Prepared)Statement : 해당 DB 에 SQL문을 전달하고
 * 							실행한 후 결과를 받아내는 객체 
 * - ResultSet : 내가 만일 실행한 SQL문이 SELECT 문일 경우
 * 				 조회된 결과들이 담겨있는 객체
 * * JDBC 처리 순서
 * 1) JDBC Driver 등록 
 * : 해당 DBMS 가 제공하고 있는 클래스 등록
 * 2) Connection 객체 생성
 * : 접속하고자 하는 DB 정보를 입력해서 DB 에 접속하면서 생성
 *   (Connection 객체 생성 == DB 에 접속)
 * 3) Statement 객체 생성
 * : Connection 객체를 이용해서 생성
 * 4) SQL 문 전달하면서 실행
 * : Statement 객체를 이용해서 SQL 문 실행
 *   - SELECT 문의 경우 : executeQuery 메소드를 이용해서 실행
 *   - DML문의 경우 : executeUpdate 메소드를 이용해서 실행
 *   (INSERT, UPDATE, DELETE 문)
 * 5) 결과 받기
 *  - SELECT 문의 경우 : ResultSet 객체 
 *  (조회된 데이터들이 담겨있음) 로 받기
 *  => 6_1)
 *  - DML 문(INSERT, UPDATE, DELETE 문)의 경우 :  int (처리된 행의 갯수)로 받기 
 *  => 6_2)
 * 6_1) ResultSet 에 담겨있는 조회된 데이터들을
 *      하나씩 뽑아서 VO 객체에 담기
 * 6_2) 트랜잭션 처리 (성공 시 COMMIT, 실패 시 ROLLBACK)
 * 7) 다 쓴 JDBC 용 자원들을 반납 (close)
 * : 단, 생성 순서의 역순으로 반납하기
 * 8) Controller 로 결과 반환
 *   - SELECT 문의 경우 : 6_1) 에서 만들어진 결과
 *   - DML 문(INSERT, UPDATE, DELETE 문)의 경우 : int (처리된 행의 갯수)
 *        		
 * ** Statement 특징 : 완성된 SQL문을 실행!!
 */
public class MemberDao {

	/**
	 * 사용자가 회원 추가 요청 시 입력했던 값들을 가지고
	 * MEMBER 테이블에 INSERT 문을 실행해주는 메소드
	 * @param m => 사용자가 입력했던 아이디 ~ 취미 까지의 값들이 담겨있는
	 * 			   Member 객체
	 * @return => Insert 된 행의 갯수
	 */
	public int insertMember(Member m) {
		// insert 문 => 처리된 행의 갯수 = > 트랜잭션 처리
		
		// 0)  필요한 변수들 먼저 셋팅
		int result = 0; // 처리된 행의 갯수를 담아줄 변수
		 Connection conn = null; // 접속할 DB 의 정보를 담을 변수
		 Statement stmt = null; // SQL 문을 전달 후 실행할 용도의 변수
		// 실행할 SQL 문 (단, 완성된 형태로 만들 것)
		// 끝에 세미콜론 (;) 이 있으면 안됨
		/*
		INSERT INTO MEMBER VALUES(SEQ_USERNO.NEXTVAL
                , 'XXX'
                , 'XXX'
                , 'XXX'
                , 'X'
                , XX
                , 'XXXX'
                , 'XXXX'
                , 'XXXX'
                , 'XXX'
                , DEFAULT);
                */
		String sql = "INSERT INTO MEMBER VALUES(SEQ_USERNO.NEXTVAL"
											+ ", '"+ m.getUserId() +"'"
											+ ", '"+ m.getUserPwd() +"'"
											+ ", '"+ m.getUserName() +"'"
											+ ", '"+ m.getGender() +"'"
											+ ", " + m.getAge() 
											+ ", '"+ m.getEmail() +"'"
											+ ", '"+ m.getPhone() +"'"
											+ ", '"+ m.getAddress() +"'"
											+ ", '"+ m.getHobby() +"'"
											+ ", DEFAULT)";
		
		try {

			//System.out.println(sql);
			
			// 1) JDBC Driver 등록
			// [ 표현법 ]
			// Class.forName("oracle.jdbc.driver.OracleDriver");
			// > ojdbc6.jar 에서제공하고있는
			//   oracle.jdbc.driver 패키지의
			//   OracleDriver 클래스를 등록해서 가져다 쓰겠다는 의미
			// > 풀클래스명에 오타가 있거나, ojdbc6.jar 연동이 안되어있다면
			//   ClassNotFoundException 예외 발생
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2) Connection 객체 생성
			// DB 접속과 관련된 정보들을 넘기면서 생성
			// [ 표현법 ]
			// Connection conn = DriverManager.getConnection(url주소, 계정명, 비번);
			// Connection 객체가 생성되는 순간 해당 DB 에 접속됨!
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			// 이 시점 부터는 DB 에 접속이 된 것
			// 3) Statement 객체 생성
			// Connection 객체를 통해서 생성해야함
			// [ 표현법 ]
			// Statement stmt = conn.createStatement();
			stmt = conn.createStatement();
			
			// 4, 5) DB 에 완성된 SQL 문을 전달하면서 실행 후
			//       결과 받기
			//  - 실행할 SQL 문 종류 : INSERT 문
			//  - 호출해야할 메소드 : executeUpdate
			// [ 표현법 ]
			// int result = stmt.executeUpdate(sql문);
			// ResultSet rset = stmt.executeQuery(sql문);
			result = stmt.executeUpdate(sql);
			// > insert 가 제대로 되었다면 1
			//   insert 가 제대로 되지 않았다면 0
			
			// 6_2 트랜잭션 처리
			// 성공이면 COMMIT, 실패면 ROLLBACK
			if(result > 0) { // 성공했을 경우 (COMMIT)
				conn.commit();
			}else { // 실패했을 경우 (ROLLBACK)
				conn.rollback();
			}
			// 7) 다 쓴 JDBC 용 자원 반납
			// 반드시 해줘야 함!! 생성 순서의 역순으로!!
			// > finally 블럭에서 작성할 것!!
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 7) 다 쓴 JDBC 용 자원 반납
			// 반드시 해줘야 함!! 생성 순서의 역순으로!!
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		// 8) Controller 로 결과 반환
		return result;
	}// insertMember 메소드 끝
	
	/**
	 * 사용자가 회원 전체 조회 요청 시
	 * MEMBER 테이블에 SELECT * 구문을 실행하는 메소드
	 * @return => 조회된 회원들의 정보들이 담겨있는 리스트
	 */
	public ArrayList<Member> selectAll(){
		// select 문 => ResultSet 객체 (여러행 조회)
		// => ArrayList<Member>
		
		// 0) 필요한 변수들 먼저 셋팅
		ArrayList<Member> list = new ArrayList<>();
		// 조회된 결과를 뽑아서 담아 줄 변수(텅 빈 리스트)
		
	    Connection conn = null; // 접속할 DB 의 정보를 담는 변수
	    Statement stmt = null; // SQL 문을 전달하고 실행할 용도의 변수	    
		ResultSet rset = null; // select 문의 실행 결과를 담아낼 변수 
		
		// 실행할 SQL 문 (완성된 형태로, 세미콜론 x)
		String sql = "SELECT * FROM MEMBER";
		
		
		try {
			//1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			//3) Statement 객체 생성
		stmt = conn.createStatement();
		
		// 4,5) SQL 문 전달해서 실행 후 결과 받기
		// - 실행할 SQL 문 종류 : SELECT 문
		// - 호출할 메소드명 : executeQuery
		rset = stmt.executeQuery(sql);
		
		// 6_1) ResultSet 의 결과를 하나씩 뽑아서
		//		VO 객체에 담기
		// > ReslutSet 또한 JDBC 용 자원이기 때문에
		// finally 블럭에서 반납해줘야 함!!
		// > 반납을 통해 데이터가 날라가기 전에 다른 변수에 옮기는 작업임
		
		// * ResultSet 객체에는 내부적으로 "커서" 가 존재함
		// > 커서 : 현재 행의 위치를 알려주는 화살표 같은 존재
		// 커서는 항상 0번째 행을 가리키고 있음
		// 커서를 한줄 (한행) 단위로 아래로 내려서 
		// 현재 커서가 가리키는 행에 데이터가 있나 없나를 검사 후
		// 있다면 각 컬럼의 값을 하나하나씩 VO로 가공해주는 단계
		
		// 더이상 뽑을 데이터가 없을 때 까지만 반복 수행
		while(rset.next()) {
			// rset.next() : 커서를 한 행 아래로 움직여 주고
			// 				 해당 행의 데이터가 존재할 경우 true / 않으면 false 반환
			
			// 이 while 문 중괄호 안에 들어왔다라는 것은
			// 현재 커서가 가리키는 행의 데이터가 있다라는 것!
			// > 컬럼값을 하나씩 다 뽑아서 VO 객체에 담는다.
			
			// MEMBER 테이블의 한 행 == Member 객체 한개
			Member m = new Member();
			
			// ResultSet 객체로부터
			// 어떤 컬럼에 해당하는 값을 뽑을 건지 제시 (매개변수로)
			// rset.getInt(매개변수) : int 형 값을 뽑아낼 때
			// rset.getString(매개변수) : String 형 값을 뽑아낼 때
			// rset.getDate(매개변수) : java.sql.Date 형 값을 뽑아낼 때 > import java.util.Date 가아님
			// rset.getDouble(매개변수) : Double 형 값을 뽑아낼 때
			// ....
			// > 각 타입별로 컬럼값들을 뽑아낼 수 있는 메소드들!!
			// 매개변수 : 컬럼명(대소문자를 가리지 않음) 또는
			//          별칭 (대소문자를 가리지 않음) 또는
			// 			컬럼의 순번
			// > 가독성 측면에서 컬럼명을 대문자로 쓰는걸 권장함
			
			m.setUserNo(rset.getInt("USERNO"));
			m.setUserId(rset.getString("USERID"));
			m.setUserPwd(rset.getString("USERPWD"));
			m.setUserName(rset.getString("USERNAME"));
			m.setGender(rset.getString("GENDER"));
			m.setAge(rset.getInt("AGE"));
			m.setEmail(rset.getString("EMAIL"));
			m.setPhone(rset.getString("PHONE"));
			m.setAddress(rset.getString("ADDRESS"));
			m.setHobby(rset.getString("HOBBY"));
			m.setEnrollDate(rset.getDate("ENROLLDATE"));
			
			// > 한 행에 대한 모든 데이터값들을
			//   하나의 Member 객체로 옮겨담는 과정 끝!!
			
			// 리스트에 해당 Member 객체를 담아둘것임
			list.add(m);
			
			
		}
		
		// 이 시점 기준으로
		// list 에는 조회된 회원들의 정보가 차곡차곡 담겨있음
		
		
		
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			// 7) 다쓴 JDBC 용 자원 반납
			// (생성 순서의 역순)
			
			
			try {
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			
			
		}
		
		// 8) Controller 로 6_1) 의 결과 반환
		return list;
		
	} // selectAll 메소드 끝
	
	/**
	 * 사용자가 아이디 검색 기능을 요청했을 때
	 * MEMBER 테이블에 SELECT 문을 실행해주는 메소드
	 * @param userId => 검색할 회원의 아이디값
	 * @return => 조회 결과 회원 한명의 정보
	 */
	public Member selectByUserId(String userId) {
		// select 문 => ResultSet 객체 (단일행)
		// => Member 객체
		
		// 0) 필요한 변수들 먼저 셋팅
		Member m = null; // 조회된 한 회원에 대한 정보를 담는 변수
		Connection conn = null; // 접속할 DB 의 연결정보를 담는 변수
		Statement stmt = null; // SQL 문 실행 후 결과를 받기 위한 변수
		ResultSet rset = null; // select 문이 실행된 조회결과들이 처음에 담겨올 변수
		
		// 실행할 SQL 문 (완성된 형태로, 세미콜론 X)
		String sql = "SELECT * FROM MEMBER WHERE USERID = '" + userId + "'";
		
		
		try {
			
			// 1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			// 3) Statement 객체 생성
			stmt = conn.createStatement();
			
			//4,5) SQL문 실행 후 결과 받기
			// - 실행할 쿼리문 종류 : SELECT 문
			// - 호출할 메소드 명 : executeQuery
			rset = stmt.executeQuery(sql);
			
			// 6_1) 현재 조회 결과가 담긴 ResultSet 에서
			// 		한명씩 뽑아서 VO 객체에 담기
			// > 기존에 여러행 조회 기능 때에는
			//   정확히 몇개의 행이 조회될지 가늠이 안됬기 때문에
			//   while(rset.next()) 을 활용했었음!!
			// > 단일행 조회 기능 때에는
			//   어차피 많이 조회되어봤자 최대 1개 행이 조회되기 때문에
			//  if(rest.next()을 활용해볼곳임!!
			if(rset.next()) {
				
				// 조회된데이터가 있다면 if문 안쪽으로 들어옴
				// > 조회된 한행에 대한 데이터값들을 모두 뽑아서
				//   하나의 Member 객체에 담기
				m = new Member(rset.getInt("USERNO"),
							   rset.getString("USERID"),
							   rset.getString("USERPWD"),
							   rset.getString("USERNAME"),
							   rset.getString("GENDER"),
							   rset.getInt("AGE"),
							   rset.getString("EMAIL"),
							   rset.getString("PHONE"),
							   rset.getString("ADDRESS"),
							   rset.getString("HOBBY"),
							   rset.getDate("ENROLLDATE"));
			}
			
			// 이시 점 기준으로 
			// 조회된 회원의 정보가 있다면 m의 각 필드에는
			// 그 정보들이 제대로 들어있을 것!!
			// 하지만, 조회된 회원의 정보가 없다면***
			// m 에는 여전히 null 이 들어가 있을 것임!!
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {
				// 7) 다 쓴 JDBC 용 자원 반납 (역순)
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
			
		}
		
		// 8) Controller 로 6_1) 에서 만들어진 결과 반환
		return m; // 조회된 결과가 없다면 null 이 리턴됨 
		
	} // selectByUserId 메소드 끝
	
	public ArrayList<Member> selectByUserName(String Keyword){
		
		// select 문 => ResultSet 객체 (여러행 조회)
		// => ArrayList<Member>
		// 0) 필요한 변수들 먼저 셋팅
		ArrayList<Member> list = new ArrayList<>();
		// 조회된 회원들의 정보를 담을 리스트(텅빈 리스트)
		Connection conn = null; // 접속할 DB 의 정보를 담는 변수
		Statement stmt = null; // SQL 문을 전달하고 실행할 용도의 변수	    
		ResultSet rset = null; // select 문의 실행 결과를 담겨서 돌아올 변수 
			
		String sql = "SELECT * FROM MEMBER WHERE USERNAME LIKE '%" + Keyword + "%'"; 
		// 실행해줄 SQL문 (완성된 형태로 , 세미콜론 X)
		
		
		
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
		
		stmt = conn.createStatement();
		
		// SQL 문 전달 후 실행 및 결과 받기
		// - 실행항 SQL 문종류 : SELECT 문
		// - 호출할 메소드 명 : executeQuery
		
		rset = stmt.executeQuery(sql);
		
		while(rset.next()) {
		
			
			//Member m = new Member();
			
//			m.setUserNo(rset.getInt("USERNO"));
//			m.setUserId(rset.getString("USERID"));
//			m.setUserPwd(rset.getString("USERPWD"));
//			m.setUserName(rset.getString("USERNAME"));
//			m.setGender(rset.getString("GENDER"));
//			m.setAge(rset.getInt("AGE"));
//			m.setEmail(rset.getString("EMAIL"));
//			m.setPhone(rset.getString("PHONE"));
//			m.setAddress(rset.getString("ADDRESS"));
//			m.setHobby(rset.getString("HOBBY"));
//			m.setEnrollDate(rset.getDate("ENROLLDATE"));
			// 아래에 한줄로 요약 쌉가능
			
			
			
			list.add(new Member(rset.getInt("USERNO"),
								rset.getString("USERID"),
								rset.getString("USERPWD"),
								rset.getString("USERNAME"),
								rset.getString("GENDER"),
								rset.getInt("AGE"),
								rset.getString("EMAIL"),
								rset.getString("PHONE"),
								rset.getString("ADDRESS"),
								rset.getString("HOBBY"),
								rset.getDate("ENROLLDATE")));
			// > 각 컬럼으로부터 값을 뽑자마자
			//   매개변수 생성자로 객체 생성과 동시에 초기화 후
			//   리스트에 한번에 add 까지 해버린 것!!
			
			
		}
		
		// 이 시점 기준으로
		// 조회 된 회원의 데이터가 있다면 list.isEmpty()가 있다면 false 없다면 true
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rset.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// Controller 로 list 결과를 반환
		return list; // 조회된 회원들의 정보가 모두 담겨있음
	} // selectByUserName 메소드 끝
	
	
	/**
	 * 변경할 회원의 정보를 전달받아서
	 * MEMBER 테이블에 UPDATE 구문을 실행할 메소드
	 * @param m => 변경할 회원의 정보를
	 * @return => 업데이트된 행의 갯수
	 */
	public int updateMember(Member m ) {
		
		// update 문 => int (처리된 행의 갯수) => 트랜잭션 처리
		
		// 0) 필요한 변수들 먼저 셋팅
		int result = 0; // 결과를 받을 변수
		Connection conn = null;
			// 접속할 DB 의 정보를 담을 변수
		Statement stmt = null;
			// SQL 문 실행 후 결과를받아낼 용도의 변수
		// 실행할 SQL 문 (완성된 형태로, 세미콜론 X)
		
		/*
					 UPDATE MEMBER 
			 SET USERPWD = 'XXX'
			   , EMAIL = 'XXXXXXXXXX'
			   , PHONE = 'XXX'
			   , ADDRESS = 'XXXXXXXXXX'
			 WHERE USERID = 'XXX'; 
		*/
		
		String sql = "UPDATE MEMBER "
					 + "SET USERPWD = '"+ m.getUserPwd() +"' "
					  + ", EMAIL = '" + m.getEmail() +"' "
					  + ", PHONE = '" + m.getPhone() +"' "
					  + ", ADDRESS = '" + m.getAddress() +"' "
					  + "WHERE USERID = '" + m.getUserId() +"' ";
		
	
		try {
			// 1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			// 3) Statement 객체 생성
			stmt = conn.createStatement();
			
			// 4,5) SQL 문 전달 후 실행 및 결과 받기
			// - 실행할 SQL 문 종류 : update 문
			// - 호출할 메소드명 : executeUpdate
			result = stmt.executeUpdate(sql);
			
			// 6_2) 트랜잭션 처리
			if(result > 0) { // 성공일 경우 (commit)
				conn.commit();
			} else { // 실패일 경우 (rolback)
				conn.rollback();
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 7) 다 쓴 JDBC 용 자원 반납 (역순)
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		// 8) Controller 로 결과 반환
		return result; // 성공 시1, 실패 시 0이 리턴됨
	}
	/**
	 * 사용자가 회원 탈퇴 요청 시
	 * MEMBER 테이블에 한 행을 DELETE 해주는 메소드
	 * @param userId => 탈퇴할 회원의 아이디
	 * @return => 삭제된 행의 갯수
	 */
	public int deleteMember(String userId) {
		
		// delete 문 = > int (처리 된 행의 갯수) => 트랜잭션 처리
		
		// 0) 필요한 변수들 먼저 셋팅
		
		
		int result = 0;
		Connection conn = null;
		Statement  stmt= null;
		
		String sql = "DELETE FROM MEMBER WHERE USERID = '" + userId + "'";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			stmt = conn.createStatement();

			result = stmt.executeUpdate(sql);
			
			if(result > 0) { // 성공일 경우 (commit)
				conn.commit();
			} else { // 실패일 경우 (rolback)
				conn.rollback();
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return result;	
		
	}
}

package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.dao.MemberDao;
import com.kh.model.vo.Member;
import com.kh.view.MemberView;

/*
 *  Controller : View 를 통해서 요청한 기능을 처리하는 담당
 *  			 해당 메소드로 전달된 데이터들을 "가공처리" 한후 
 * 				 Dao 메소드 호출 시 전달
 * 				 Dao 로 부터 반환받은 결과에 따라 사용자가 보게 될
 * 				 View (응답화면) 을 결정
 * 
 * Controller 메소드 코드 flow
 * 1) 매개변수로 전달받은 전달값들을 하나의 VO 객체에 담기 (가공)
 * 2) Dao 단의 메소드를 호출하면서 VO 객체 전달하면서 결과 받기
 * 3) Dao 로 부터 전달받은 결과에 따른 응답 화면을 결정
 * 
 */
public class MemberController {

	/**
	 * 사용자의 회원 추가 요청을 처리해주는 메소드
	 * @param userId
	 * @param userPwd
	 * @param userName
	 * @param gender
	 * @param age
	 * @param email
	 * @param phone
	 * @param address
	 * @param hobby
	 * => 사용자가 회원 추가 요청 시 입력했던 값들
	 */
	public void insertMember(String userId,
							 String userPwd,
							 String userName,
							 String gender,
							 int age,
							 String email,
							 String phone,
							 String address,
							 String hobby) {
		// 1) 전달된 데이터들을 Member 객체로 가공하기
		Member m = new Member(userId,userPwd,userName,gender
							 ,age,email,phone,address,hobby);
		
		// 2) Member 객체를 DAO 의 메소드로 넘기면서 호출
		//    결과값 받기
		int result = new MemberDao().insertMember(m);
		
		// 3) 결과에 따른 응답화면 지정
		if(result > 0) { // 성공했을 경우
			
			// 성공 화면을 띄워줄 것
			// > 성공 화면을 나타내는 메소드 작성 후 호출
			new MemberView().displaySuccess("회원 추가 성공");
		
		}else { // 실패했을 경우
			
			// 실패 화면을 띄워줄 것
			// > 실패 화면을 나타내는 메소드 작성 후 호출
			new MemberView().displayFail("회원 추가 실패");
			
		}
	} // insertMember 메소드 끝
	
	/**
	 * 사용자의 회원 전체 조회 요청을 처리해주는 메소드
	 */
	public void selectAll() {
		
		// 1) 전달된 데이터들을 Member 객체로 가공하기
		// > 전달된 데이터들이 없으므로 패스
		
		// 2) DAO 로 메소드 호출 후 결과 받기
		// > 요청 시 전달값이 없으므로 매개면수 없이 호출
		ArrayList<Member> list = new MemberDao().selectAll();
		// > SELECT 문을 이용한 조회 기능은 크게 2가지로 나뉜다.
		// - 여러행 조회 : 2개 이상의 데이터가 조회될 경우 (ArrayList)
		// - 단일행 조회 : 많아봤자 최대 1개의 데이터가 조회될 경우(VO)
		
		// 3) 결과에 따른 응답화면 지정
		// > 조회 결과가 있는지 없는지 판별 후
		//   그에 맞는 사용자가 보게 될 화면으로 각각 지정
		if(list.isEmpty()) { // 조회 결과가 없을 경우
			
			new MemberView().displayNodata("전체 조회 결과가 없습니다.");
			
		} else { // 조회 결과가 있을 경우
			
			new MemberView().dsiplayList(list);
			
			
		} 
		
		
		
		
		
		
		
	}// selectAll 메소드 끝
	/**
	 * 사용자의 아이디로 검색 요청을 처리해주는 메소드
	 * @param userId => 검색하고자 하는 회원의 아이디값
	 */
	public void selectByUserId(String userId) {
		
		// 1) 요청 시 전달값을 하나의 Member 객체로 담기
		// > 어차피 전달값이 userId 한개 이기 때문에
		// 가공하는 과정 패스!!
		
		// 2) DAO 로 전달값을 넘기면서 호출 후 결과 받기
		Member m = new MemberDao().selectByUserId(userId);
		// > 아이디로 검색하겠다.
		//   아디는 unique 제약조건이 걸린 컬럼이므로
		// 	 일치하는 아이디에 대한 회원은 최대 1명밖에 조회 안됨!!
		//	 즉, 단일행 조회 기능임!!
		
		// 3) 결과에 따른 응답화면 지정
		if(m==null) { //조회결과가 없을 경우
			new MemberView().displayNodata(userId + "에 해당되는 검색결과가없습니다.");
		}else { // 조회 결과가 있을 경우
		
			new MemberView().displayOne(m);
		}
			
	} // selectByUserId 메소드 영역 끝
	
	/**
	 * 사용자의 회원명 키워드로 검색 요청 시 처리해주는 메소드
	 * @param keyword => 사용자가 입력했던 검색하고자 하는 회원명 키워드
	 */
	public void selectByUserName(String keyword) {
		
		// 1) 요청 시 전달값들을 Member 객체로 가공하기
		// > 요청 시 전달값이 1개이기 때문에 패스
		
		// 2) DAO 로 전달값을 넘기면서 호출 후 결과값 받기
		ArrayList<Member> list  
		= new MemberDao().selectByUserName(keyword);
		// > 여러행 조회 (동명이인이 있을 수도 있음)
		
		// 결과에 따른 응답화면 처리
		if(list.isEmpty()/* isEmpty 는 리스트에 들어가있는게 0이라면 false 있다면 true를 반환한다.*/) { // 조회가 없을경우
		    new MemberView().displayNodata(keyword +"의 결과가 없습니다.");
		} else { // 조회가 있을경우
		   new MemberView().dsiplayList(list);
		}
	} // selectByUserName 메소드 영여 끝
	public void updateMember(String userId,String newPwd,
							 String newEmail, String newPhone,
							 String newAddress) {
		
		// 1) 요청 시 전달받은 값들의 하나의 Member 객체로 가공
		Member m = new Member();
		m.setUserId(userId);
		m.setUserPwd(newPwd);
		m.setEmail(newEmail);
		m.setPhone(newPhone);
		m.setAddress(newAddress);
		
		// 2) DAO 로 전달값을 넘기면서 메소드 호출 후 결과 받기
		int result = new MemberDao().updateMember(m);
		
		// 3) 결과에 따른 응답 화면 지정
		if(result > 0) { // 성공
			
			new MemberView().displaySuccess("회원 정보 변경 성공");
			
		}else { // 실패
			new MemberView().displayFail("회원 정보 변경 실패");
		}
	}
	
	/**
	 * 사용자가 회원 탈퇴 요청 시 처리해주는 메소드
	 * @param userId => 탈퇴할 회원의 아이디값
	 */
	public void deleteMember(String userId) {
	
		// 1) 요청 시 전달값을 Member 객체로 가공하기
		// > 요청 시 전달값이 한개이기 때문에 패스
		
		// 2) Dao 로 요청 시 전달값을 넘기면서 메소드 호출 후
		//  결과받기
		
		int result = new MemberDao().deleteMember(userId);
		
		if(result > 0) { // 성공
			
			new MemberView().displaySuccess("회원 정보 탈퇴 성공!");
			
		}else { // 실패
			new MemberView().displayFail("회원 정보 탈퇴 실패!");
		}
		
	}
	
	
}
